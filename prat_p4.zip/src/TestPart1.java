public class TestPart1 {
    public static void main(String[] args) {
        Tests.test_automata();
        Tests.test_lexer1();
        Tests.test_lexer2();
    }
}
