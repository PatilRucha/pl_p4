public class TestPart2 {
    public static void main(String[] args) throws Exception {
        Tests.test_recognizer();
        Tests.test_parser();
    }
}
